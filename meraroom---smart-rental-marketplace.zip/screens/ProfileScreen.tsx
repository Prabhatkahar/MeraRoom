
import React, { useState, useEffect } from 'react';
import { useTranslation, Language } from '../context/LanguageContext';
import { useInstall } from '../context/InstallContext';
import { 
  UserCircleIcon, 
  CheckIcon, 
  ShieldCheckIcon, 
  CameraIcon, 
  MapPinIcon, 
  LanguageIcon,
  ArrowDownTrayIcon,
  SparklesIcon,
  ChevronRightIcon,
  ShareIcon,
  BellIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';

const ProfileScreen: React.FC = () => {
  const { t, language, setLanguage } = useTranslation();
  const { isInstallable, isInstalled, promptInstall } = useInstall();
  const [showToast, setShowToast] = useState<string | null>(null);
  const [permissionStatus, setPermissionStatus] = useState({
    camera: 'unknown',
    location: 'unknown'
  });

  const checkPermissions = () => {
    if ('permissions' in navigator) {
      Promise.all([
        navigator.permissions.query({ name: 'camera' as any }).catch(() => null),
        navigator.permissions.query({ name: 'geolocation' as any }).catch(() => null)
      ]).then(([camera, geo]) => {
        setPermissionStatus({
          camera: camera?.state || 'unknown',
          location: geo?.state || 'unknown'
        });
      });
    }
  };

  useEffect(() => {
    checkPermissions();
  }, []);

  const requestCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach(t => t.stop());
      checkPermissions();
    } catch (err) {
      setShowToast("Access Denied");
    }
  };

  const requestLocation = () => {
    navigator.geolocation.getCurrentPosition(() => {
      checkPermissions();
    }, () => {
      setShowToast("Access Denied");
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'granted': return 'bg-emerald-100 text-emerald-700';
      case 'denied': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-500';
    }
  };

  const handleShareApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'MeraRoom',
          text: 'Find your perfect rental room with MeraRoom!',
          url: window.location.origin
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    }
  };

  return (
    <div className="flex flex-col animate-fade-in bg-slate-50 min-h-screen pb-24 relative">
      {showToast && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[100] bg-gray-900/90 backdrop-blur-md text-white px-6 py-3 rounded-2xl text-xs font-black shadow-2xl flex items-center gap-2 border border-white/10 animate-slide-up">
          <CheckIcon className="w-4 h-4 text-emerald-400" />
          {showToast}
        </div>
      )}

      <header className="bg-white p-6 pb-12 rounded-b-[50px] shadow-sm relative overflow-hidden text-center">
        <div className="absolute top-0 right-0 -mr-10 -mt-10 w-40 h-40 bg-indigo-50 rounded-full blur-3xl opacity-50"></div>
        <div className="w-24 h-24 bg-gradient-to-tr from-indigo-500 to-indigo-600 rounded-3xl flex items-center justify-center border-4 border-white shadow-2xl mx-auto rotate-3 mb-4">
          <UserCircleIcon className="w-16 h-16 text-white" />
        </div>
        <h1 className="text-2xl font-black text-gray-900">{t('guest_user')}</h1>
        <p className="text-gray-500 font-bold text-sm tracking-tight">{t('privacy_controls')}</p>
      </header>

      <div className="px-6 -mt-8 space-y-6">
        {/* Install Card */}
        {isInstallable && !isInstalled && (
          <section className="bg-indigo-600 rounded-[32px] p-6 text-white shadow-xl shadow-indigo-100 relative overflow-hidden group">
            <div className="absolute top-0 right-0 -mr-4 -mt-4 opacity-10">
              <ArrowDownTrayIcon className="w-24 h-24" />
            </div>
            <div className="relative z-10 space-y-4">
              <div className="flex items-center gap-2">
                <SparklesIcon className="w-5 h-5 text-amber-300" />
                <h3 className="text-sm font-black uppercase tracking-widest">Install App</h3>
              </div>
              <p className="text-[11px] text-indigo-100">Unlock full offline features and faster property browsing.</p>
              <button onClick={promptInstall} className="w-full bg-white text-indigo-600 font-black py-3 rounded-2xl text-xs uppercase tracking-widest active:scale-95 transition-all">
                Install Now
              </button>
            </div>
          </section>
        )}

        {/* Language Selection */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-xs font-black text-gray-400 uppercase tracking-widest">{t('language')}</h2>
            <LanguageIcon className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="bg-white rounded-[32px] p-2 border border-gray-100 flex shadow-sm">
            <button onClick={() => setLanguage('en')} className={`flex-1 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${language === 'en' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-gray-400'}`}>English</button>
            <button onClick={() => setLanguage('hi')} className={`flex-1 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${language === 'hi' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-gray-400'}`}>हिन्दी</button>
          </div>
        </section>

        {/* Hardware Permissions Manager */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-xs font-black text-gray-400 uppercase tracking-widest">{t('privacy_controls')}</h2>
            <ShieldCheckIcon className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="bg-white rounded-[32px] border border-gray-100 overflow-hidden shadow-sm">
            <div className="p-5 flex items-center justify-between border-b border-gray-50">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-indigo-600">
                  <MapPinIcon className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-sm font-bold text-gray-700 block">Location Access</span>
                  <button onClick={requestLocation} className="text-[10px] text-indigo-500 font-black uppercase tracking-widest">Request Now</button>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${getStatusColor(permissionStatus.location)}`}>
                {permissionStatus.location}
              </span>
            </div>

            <div className="p-5 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-indigo-600">
                  <CameraIcon className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-sm font-bold text-gray-700 block">Camera Access</span>
                  <button onClick={requestCamera} className="text-[10px] text-indigo-500 font-black uppercase tracking-widest">Request Now</button>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${getStatusColor(permissionStatus.camera)}`}>
                {permissionStatus.camera}
              </span>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-[32px] border border-gray-100 overflow-hidden shadow-sm divide-y divide-gray-50">
          <button onClick={handleShareApp} className="w-full p-5 flex items-center justify-between active:bg-gray-50 transition-colors">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600">
                <ShareIcon className="w-5 h-5" />
              </div>
              <span className="text-sm font-bold text-gray-700">Share App</span>
            </div>
            <ChevronRightIcon className="w-5 h-5 text-gray-300" />
          </button>
        </section>

        <p className="text-center text-[10px] text-gray-400 font-bold uppercase tracking-widest pb-10">MeraRoom v1.5.0 • PWA Ready</p>
      </div>
    </div>
  );
};

export default ProfileScreen;
