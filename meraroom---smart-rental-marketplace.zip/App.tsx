
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomeScreen from './screens/HomeScreen';
import PostRoomScreen from './screens/PostRoomScreen';
import RoomDetailScreen from './screens/RoomDetailScreen';
import InquiriesScreen from './screens/InquiriesScreen';
import ProfileScreen from './screens/ProfileScreen';
import SavedRoomsScreen from './screens/SavedRoomsScreen';
import InstallBanner from './components/InstallBanner';
import { SavedRoomsProvider } from './context/SavedRoomsContext';
import { LanguageProvider, useTranslation } from './context/LanguageContext';
import { InstallProvider } from './context/InstallContext';
import { WifiIcon } from '@heroicons/react/24/solid';

const OfflineNotification: React.FC = () => {
  const { t } = useTranslation();
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!isOffline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[100] bg-red-600 text-white px-4 py-1.5 flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest animate-fade-in">
      <WifiIcon className="w-3 h-3" />
      {t('working_offline')}
    </div>
  );
};

const AppContent: React.FC = () => {
  return (
    <Router>
      <div className="relative">
        <OfflineNotification />
        <Layout>
          <InstallBanner />
          <Routes>
            <Route path="/" element={<HomeScreen />} />
            <Route path="/room/:id" element={<RoomDetailScreen />} />
            <Route path="/post" element={<PostRoomScreen />} />
            <Route path="/inquiries" element={<InquiriesScreen />} />
            <Route path="/saved" element={<SavedRoomsScreen />} />
            <Route path="/profile" element={<ProfileScreen />} />
          </Routes>
        </Layout>
      </div>
    </Router>
  );
};

const App: React.FC = () => {
  return (
    <InstallProvider>
      <LanguageProvider>
        <SavedRoomsProvider>
          <AppContent />
        </SavedRoomsProvider>
      </LanguageProvider>
    </InstallProvider>
  );
};

export default App;
